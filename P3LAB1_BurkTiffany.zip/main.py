r = int(input())
g = int(input())
b = int(input())

m = min(r, g, b)

print((r - m), (g - m), (b - m))
