user_int = int(input('Enter integer (32 - 126):\n'))

amt_float = float(input('Enter float:\n'))
input_character = input('Enter character:\n')
the_string = input('Enter string:\n')

print(user_int,amt_float,input_character,the_string)

print(the_string,input_character,amt_float,user_int)

print(user_int,'converted to a character is',chr(user_int))