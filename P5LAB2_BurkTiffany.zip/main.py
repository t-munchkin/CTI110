# Define your function here 
def feet_to_steps(user_feet):
    steps = (user_feet / 2.5)
    num_steps = int(steps)
    return num_steps

if __name__ == '__main__':
    user_feet = float(input())
    num_steps = feet_to_steps(user_feet)
    print(num_steps)